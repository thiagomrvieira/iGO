<!DOCTYPE html>
<html>
<head>
    <title>iGO - É só pedir!</title>
</head>
<body>
    <h1>Olá, {{ $partner['name'] }}</h1>
    <p>O pré cadastro da {{ $partner['company_name'] }} foi efetuado. Aguarde até entrarmos em contato e ativar a sua conta para que possas inserir dados.</p>
   
    <p>Obrigado!</p>
</body>
</html>
<footer class="main-footer">
    <strong>iGO &copy; 2021 - {{ __('backoffice/footer.access') }} <a href="{{ route('home') }}" target="_blank">{{ __('backoffice/footer.homepage') }}</a>.</strong>
    <div class="float-right d-none d-sm-inline-block">
        <b>{{ __('backoffice/footer.version') }}</b> 1.0.0
    </div>
</footer>
<div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="{{ asset('assets-backoffice/dist/img/iGOLogo.png') }}" alt="AdminLTELogo" height="90" width="90">
</div>
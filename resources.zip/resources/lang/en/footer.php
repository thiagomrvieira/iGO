<?php

return [
	// Nav
	'footer-nav-about' => 'About us',
	'footer-nav-partners' => 'Partners',
	'footer-nav-couriers' => 'Couriers',
	'footer-nav-contacts' => 'Contacts',
	'footer-nav-faqs' => 'FAQs',
	'footer-nav-terms-conditions' => 'Terms and conditions',
	// Newsletter
	'footer-newsletter-send' => 'Send',
];

?>
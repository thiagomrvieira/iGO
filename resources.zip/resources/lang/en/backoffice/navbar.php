<?php

    /*
    |--------------------------------------------------------------------------
    | View Navbar Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the portuguese translation...
    |
    */

    return [ 
        'home' => "Home",
        'logout' => "Sair",
    ]
?>
<nav class="navbar ">
    <ul class="nav navbar-nav ms-auto">
        <li class="nav-item">
            <a class="nav-link" href="{{route('home')}}"> Home </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="{{route('partner.createBusiness.data')}}"> Dados negócios </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="{{route('products.index')}}"> Dados produtos </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="{{route('partner.profile.edit')}}"> Perfil </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="{{route('logout')}}"> Logout </a>
        </li>
    </ul>
</nav>

<!DOCTYPE html>
<html>
<head>
    <title>iGO - É só pedir!</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1>
    <p>{{ $details['body'] }}</p>
   
    <p>Thank you</p>
</body>
</html>
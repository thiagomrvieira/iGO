<?php

    /*
    |--------------------------------------------------------------------------
    | View Footer Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the portuguese translation...
    |
    */

    return [ 
        'access' => "Acesse a ",
        'homepage' => "página inicial",
        'version' => "Versão",
    ]
?>
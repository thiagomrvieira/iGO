<?php

    /*
    |--------------------------------------------------------------------------
    | View Login Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the portuguese translation...
    |
    */

    return [ 
        'email' => "E-mail",
        'password' => "Palavra passe",
        'remember' => "Lembrar",
        'login' => "Entrar",
    ]
?>
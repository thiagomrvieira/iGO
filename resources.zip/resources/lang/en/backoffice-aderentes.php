<?php

return [
	'partner-title' => 'Bem-vindo!',
	'partner-subtitle' => 'Está a um passo de se tornar um parceiro iGO. Preencha as informações em falta e bons negócios.',
];
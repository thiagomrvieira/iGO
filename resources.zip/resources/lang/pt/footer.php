<?php

return [
	// Nav
	'footer-nav-about' => 'Sobre nós',
	'footer-nav-partners' => 'Parceiros',
	'footer-nav-couriers' => 'Estafetas',
	'footer-nav-contacts' => 'Contactos',
	'footer-nav-faqs' => 'FAQs',
	'footer-nav-terms-conditions' => 'Termos e Condições',
	// Newsletter
	'footer-newsletter-send' => 'Enviar',
];


<?php

return [
	// Nav
	'header-nav-home' => 'Home',
	'header-nav-about' => 'Soubre nós',
	'header-nav-login' => 'Login aderentes',
];
<?php
    return [ 
        'slogan' => "É só pedir!",
        'deliverymen' => "Estafetas",
        'partners' => "Aderentes",
        'preregistation' => "Pré-cadasto",
        'categories' => "Categorias",
        'websitecontent' => "Conteúdo do site",
        'about' => "Sobre nós",
        'faqs' => "FAQs",
        'conditions' => "Termos e condições",
        'contacts' => "Contatos",
    ]
?>
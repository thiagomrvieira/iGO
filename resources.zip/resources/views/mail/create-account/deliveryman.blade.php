<!DOCTYPE html>
<html>
<head>
    <title>iGO - É só pedir!</title>
</head>
<body>
    <h1>Olá, {{ $deliveryman['name'] }}</h1>
    <p>O seu pré cadastro foi feito. Aguarde até entrarmos em contato e ativar a sua conta.</p>
   
    <p>Obrigado!</p>
</body>
</html>
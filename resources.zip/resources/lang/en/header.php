<?php

return [
	// Nav
	'header-nav-home' => 'Home',
	'header-nav-about' => 'About us',
	'header-nav-login' => 'Adherent login',
];